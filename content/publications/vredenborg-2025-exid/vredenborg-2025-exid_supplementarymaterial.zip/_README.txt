#########READ ME##########
The supplementary material for the "EXID: Development and Validation of the Experienced Impact of Disruptions Scale" paper contains the following files: 

1. Initial items - An Excel file containing the list of the initial items. 
2. Items following expert reviews - An Excel file containing the refined list of items after Expert reviews. 
3. Qualtrics Survey (EFA) - A PDF with the survey used for collecting data to perform the EFA and reliability tests.
4. Qualtrics Survey (CFA) - A PDF with the survey used for collecting data to perform the CFA and comparison between known groups.
5. Qualtrics Survey (test-retest) - A PDF with the survey used for collecting data to perform the test-retest reliability.


